import { usestate } from "react";

function signup () {
    const [Username, setusername ] = usestate()
    const [ Email, setEmail  ] = usestate()
    const [Password, setpassword] = usestate()
    const [confrim Password, setconfrimpassword] = usestate()
    const [Phonenumber, setphonenumber] = usestate()
    const [gender, choosegender] = usestate()

    const handlesubmit =(e) => {
        e.preventDefault()
    axios.post('mongodb://localhost:27017/registration',{ Username,Email,Password,confrim genderpassword,Phonenumber,})
    .then(result => console.log(result))
    .catch(err=> console.log(err))

    }



    return (
        <div class="registration-container">
    <h2>Registration</h2>

        <div class="form-group">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>

        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div class="form-group">
            <label for="confirm password">confirm Password</label>
            <input type="confirm password" id="confirm password" name="confirm password" required>
        </div>
        <div class="form-group">
            <label for="Phone Number">Phone Number</label>
            <input type="Phone Number" id="Phone Number" name="Phone Number" required>
        </div>

        <div class="form-group">
            <select id="Gender" name="Gender" required>

            <option value="Gender">Gender</option>
            <option value="Female">Female </option>
            <option value="Male">Male</option>
            <option value="Male">Other</option>
            

        </select>
           
        </div>
        
        <div class="form-group">
        <select id="Varieties of cases" name="Varieties of cases" required>
            <option value=" disabled selected">Select your issues </option>
            <option value="Depression">Depression</option>
            <option value="Anxiety Disorders">Anxiety Disorders</option>
            <option value="Mood Disorders">Mood Disorders</option>
            <option value="Eating Disorders">Eating Disorders</option>
            <option value="Personality Disorders">Personality Disorders</option>
            <option value="Substance-Related and Addictive Disorders">Substance-Related and Addictive Disorders</option>
        
        
            
            <!-- Add more options as needed -->
        </select>-
        </div>
        <div class="form-group">
            <label for="Text type">Others issues</label>
            <input type="Text type" id="Text type" name="Text type" required>
        
    </div>
        

        <div class="form-group">
            <button type="submit">Register</button>
        </div>
</div>


        

    );
}